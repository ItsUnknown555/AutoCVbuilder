import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { resumeSchema, insertResumeSchema } from "@shared/schema";
import { suggestJobTitles, suggestSkills, correctGrammar, optimizeResume } from "./openai";

export async function registerRoutes(app: Express): Promise<Server> {
  // AI-related routes
  app.post("/api/ai/suggest-job-titles", async (req: Request, res: Response) => {
    try {
      const { description } = req.body;
      
      if (!description || typeof description !== "string") {
        return res.status(400).json({ error: "Description is required" });
      }
      
      const jobTitles = await suggestJobTitles(description);
      return res.json({ jobTitles });
    } catch (error) {
      console.error("Error suggesting job titles:", error);
      return res.status(500).json({ error: "Failed to suggest job titles" });
    }
  });

  app.post("/api/ai/suggest-skills", async (req: Request, res: Response) => {
    try {
      const { jobTitle, experience } = req.body;
      
      if (!jobTitle || typeof jobTitle !== "string") {
        return res.status(400).json({ error: "Job title is required" });
      }
      
      if (!experience || typeof experience !== "string") {
        return res.status(400).json({ error: "Experience is required" });
      }
      
      const skills = await suggestSkills(jobTitle, experience);
      return res.json({ skills });
    } catch (error) {
      console.error("Error suggesting skills:", error);
      return res.status(500).json({ error: "Failed to suggest skills" });
    }
  });

  app.post("/api/ai/correct-grammar", async (req: Request, res: Response) => {
    try {
      const { text } = req.body;
      
      if (!text || typeof text !== "string") {
        return res.status(400).json({ error: "Text is required" });
      }
      
      const correctedText = await correctGrammar(text);
      return res.json({ text: correctedText });
    } catch (error) {
      console.error("Error correcting grammar:", error);
      return res.status(500).json({ error: "Failed to correct grammar" });
    }
  });

  app.post("/api/ai/optimize-resume", async (req: Request, res: Response) => {
    try {
      const { resumeData } = req.body;
      
      if (!resumeData) {
        return res.status(400).json({ error: "Resume data is required" });
      }
      
      // Validate the resume data against our schema
      try {
        resumeSchema.parse(resumeData);
      } catch (validationError) {
        return res.status(400).json({ error: "Invalid resume data format" });
      }
      
      const optimizedResume = await optimizeResume(resumeData);
      return res.json({ resume: optimizedResume });
    } catch (error) {
      console.error("Error optimizing resume:", error);
      return res.status(500).json({ error: "Failed to optimize resume" });
    }
  });

  // Resume CRUD routes
  app.get("/api/resumes", async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId;
      
      if (!userId || typeof userId !== "string") {
        return res.status(400).json({ error: "User ID is required" });
      }
      
      const resumes = await storage.getResumesByUserId(parseInt(userId));
      return res.json({ resumes });
    } catch (error) {
      console.error("Error fetching resumes:", error);
      return res.status(500).json({ error: "Failed to fetch resumes" });
    }
  });

  app.get("/api/resumes/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid resume ID" });
      }
      
      const resume = await storage.getResume(id);
      
      if (!resume) {
        return res.status(404).json({ error: "Resume not found" });
      }
      
      return res.json({ resume });
    } catch (error) {
      console.error("Error fetching resume:", error);
      return res.status(500).json({ error: "Failed to fetch resume" });
    }
  });

  app.post("/api/resumes", async (req: Request, res: Response) => {
    try {
      const { userId, title, data } = req.body;
      
      if (!userId || typeof userId !== "number") {
        return res.status(400).json({ error: "User ID is required and must be a number" });
      }
      
      if (!title || typeof title !== "string") {
        return res.status(400).json({ error: "Title is required" });
      }
      
      if (!data) {
        return res.status(400).json({ error: "Resume data is required" });
      }
      
      // Validate the resume data
      try {
        resumeSchema.parse(data);
      } catch (validationError) {
        return res.status(400).json({ error: "Invalid resume data format" });
      }
      
      const insertData = {
        userId,
        title,
        data
      };
      
      // Validate against insert schema
      try {
        insertResumeSchema.parse(insertData);
      } catch (validationError) {
        return res.status(400).json({ error: "Invalid resume data" });
      }
      
      const newResume = await storage.createResume(insertData);
      return res.status(201).json({ resume: newResume });
    } catch (error) {
      console.error("Error creating resume:", error);
      return res.status(500).json({ error: "Failed to create resume" });
    }
  });

  app.put("/api/resumes/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { data } = req.body;
      
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid resume ID" });
      }
      
      if (!data) {
        return res.status(400).json({ error: "Resume data is required" });
      }
      
      // Validate the resume data
      try {
        resumeSchema.parse(data);
      } catch (validationError) {
        return res.status(400).json({ error: "Invalid resume data format" });
      }
      
      const updatedResume = await storage.updateResume(id, data);
      
      if (!updatedResume) {
        return res.status(404).json({ error: "Resume not found" });
      }
      
      return res.json({ resume: updatedResume });
    } catch (error) {
      console.error("Error updating resume:", error);
      return res.status(500).json({ error: "Failed to update resume" });
    }
  });

  app.delete("/api/resumes/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid resume ID" });
      }
      
      const deleted = await storage.deleteResume(id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Resume not found" });
      }
      
      return res.json({ success: true });
    } catch (error) {
      console.error("Error deleting resume:", error);
      return res.status(500).json({ error: "Failed to delete resume" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
