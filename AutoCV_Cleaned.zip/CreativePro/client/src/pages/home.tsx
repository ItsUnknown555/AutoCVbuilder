import { useContext, useRef, useState } from "react";
import { ResumeContext, SettingsContext } from "@/App";
import ResumeForm from "@/components/ResumeForm";
import ResumePreview from "@/components/ResumePreview";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Download, FileText, Brain } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Home() {
  const { resumeData } = useContext(ResumeContext);
  const { settings } = useContext(SettingsContext);
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const resumeRef = useRef<HTMLDivElement>(null);

  const exportToPDF = () => {
    if (!resumeRef.current) return;

    const element = resumeRef.current;
    const opt = {
      margin: [0, 0, 0, 0],
      filename: `${resumeData.personalDetails.name || 'resume'}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };

    // @ts-ignore - html2pdf is imported in main.tsx and available globally
    window.html2pdf().set(opt).from(element).save().then(() => {
      toast({
        title: "PDF Generated",
        description: "Your resume has been exported to PDF successfully!"
      });
    }).catch((error: any) => {
      console.error("PDF generation failed:", error);
      toast({
        title: "Export Failed",
        description: "There was an error exporting your resume to PDF.",
        variant: "destructive"
      });
    });
  };

  const [showWelcome, setShowWelcome] = useState(true);

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700 px-4 py-3 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center">
          <FileText className="h-6 w-6 text-primary mr-2" />
          <h1 className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">AutoCV Builder</h1>
        </div>
        <div className="flex items-center gap-3">
          <Button 
            onClick={exportToPDF} 
            className="gap-1.5 shadow-sm hover:shadow-md transition-shadow"
            variant="default"
          >
            <Download className="h-4 w-4" />
            Export PDF
          </Button>
          <div className="flex items-center">
            <ThemeToggle />
          </div>
        </div>
      </header>

      {/* Welcome Message */}
      {showWelcome && (
        <div className="bg-gradient-to-r from-purple-500/20 to-blue-500/20 dark:from-purple-500/30 dark:to-blue-500/30 border-b border-gray-200 dark:border-gray-700 py-8">
          <Card className="max-w-4xl mx-auto bg-white/90 dark:bg-gray-800/90 backdrop-blur shadow-xl border-none overflow-hidden relative">
            {/* Decorative elements */}
            <div className="absolute -top-10 -left-10 w-40 h-40 bg-purple-500/10 dark:bg-purple-500/20 rounded-full blur-2xl"></div>
            <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-blue-500/10 dark:bg-blue-500/20 rounded-full blur-2xl"></div>
            
            <CardContent className="p-8 relative z-10">
              <div className="flex flex-col items-center text-center space-y-5">
                <h2 className="text-4xl font-extrabold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                  Welcome to AutoCV Builder 👋
                </h2>
                <p className="text-xl text-gray-700 dark:text-gray-300 max-w-2xl leading-relaxed">
                  Build your professional resume effortlessly with smart, AI-powered tools. Just enter your details, customize your style, and download your polished CV — all in minutes!
                </p>
                
                <div className="flex flex-wrap justify-center gap-4 pt-3">
                  <Badge variant="outline" className="text-sm py-2 px-4 bg-white/80 dark:bg-gray-700/80 flex items-center gap-2 border-purple-200 dark:border-purple-800">
                    <FileText className="h-3.5 w-3.5 text-purple-500" />
                    <span>Real-time Preview</span>
                  </Badge>
                  <Badge variant="outline" className="text-sm py-2 px-4 bg-white/80 dark:bg-gray-700/80 flex items-center gap-2 border-indigo-200 dark:border-indigo-800">
                    <Brain className="h-3.5 w-3.5 text-indigo-500" />
                    <span>AI Suggestions</span>
                  </Badge>
                  <Badge variant="outline" className="text-sm py-2 px-4 bg-white/80 dark:bg-gray-700/80 flex items-center gap-2 border-blue-200 dark:border-blue-800">
                    <Download className="h-3.5 w-3.5 text-blue-500" />
                    <span>PDF Download</span>
                  </Badge>
                </div>
                
                <Button 
                  variant="default" 
                  className="mt-4 px-8 py-6 text-lg font-medium shadow-md hover:shadow-lg transition-all" 
                  onClick={() => setShowWelcome(false)}
                >
                  Get Started
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 flex flex-col lg:flex-row overflow-hidden p-4 gap-6 max-w-7xl mx-auto w-full">
        {/* Form Section */}
        <div className="w-full lg:w-1/2 lg:overflow-y-auto">
          <ResumeForm />
        </div>

        {/* Preview Section */}
        <div className="w-full lg:w-1/2 bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 overflow-hidden border border-gray-100 dark:border-gray-700 transition-all duration-300 hover:shadow-lg">
          <h2 className="text-lg font-semibold mb-4 pb-2 border-b flex items-center justify-between">
            <span className="flex items-center">
              <FileText className="h-5 w-5 text-primary mr-2" />
              Preview
            </span>
            <div className="text-sm font-medium px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded-md text-gray-700 dark:text-gray-300">
              Template: {settings.template.charAt(0).toUpperCase() + settings.template.slice(1)}
            </div>
          </h2>
          <div 
            className="overflow-auto bg-white shadow-inner p-5 max-w-full rounded-lg border border-gray-100" 
            ref={resumeRef}
            style={{ 
              maxHeight: "calc(100vh - 230px)",
              boxShadow: "inset 0 2px 4px 0 rgba(0,0,0,0.05)" 
            }}
          >
            <ResumePreview />
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 py-5 text-center text-gray-600 dark:text-gray-400 mt-auto">
        <div className="text-sm">
          Powered by <span className="font-semibold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">AutoCV Builder</span>
        </div>
        <div className="text-xs mt-1.5 italic">
          Your Future, One Resume Away.
        </div>
      </footer>
    </div>
  );
}
