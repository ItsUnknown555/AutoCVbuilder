import { Resume } from "@shared/schema";
import { Mail, Phone, MapPin, Calendar, Link as LinkIcon, Layers } from "lucide-react";

interface ModernTemplateProps {
  resume: Resume;
}

export default function ModernTemplate({ resume }: ModernTemplateProps) {
  const { personalDetails, education, experience, skills, languages, socialLinks } = resume;

  // Check if sections have content
  const hasPhoto = Boolean(personalDetails.photo);
  const hasSummary = Boolean(personalDetails.summary);
  const hasEducation = education && education.length > 0;
  const hasExperience = experience && experience.length > 0;
  const hasSkills = skills && skills.length > 0;
  const hasLanguages = languages && languages.length > 0;
  const hasSocialLinks = socialLinks && socialLinks.length > 0;

  return (
    <div className="min-w-[740px] max-w-[800px] mx-auto bg-white">
      {/* Header - Full Width Color Bar */}
      <header className="py-8 px-8" style={{ backgroundColor: 'var(--primary-color)' }}>
        <div className="flex items-center justify-between">
          <div className="text-white">
            <h1 className="text-3xl font-bold mb-1">
              {personalDetails.name || "Your Name"}
            </h1>
            <h2 className="text-xl opacity-90 mb-4">
              {personalDetails.title || "Professional Title"}
            </h2>
            
            <div className="flex flex-wrap gap-4 text-sm opacity-80">
              {personalDetails.email && (
                <div className="flex items-center gap-1">
                  <Mail className="w-4 h-4" />
                  <span>{personalDetails.email}</span>
                </div>
              )}
              
              {personalDetails.phone && (
                <div className="flex items-center gap-1">
                  <Phone className="w-4 h-4" />
                  <span>{personalDetails.phone}</span>
                </div>
              )}
              
              {personalDetails.address && (
                <div className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  <span>{personalDetails.address}</span>
                </div>
              )}
            </div>
          </div>
          
          {hasPhoto && (
            <div className="flex justify-end">
              <div className="w-32 h-32 bg-white p-1 rounded-full overflow-hidden flex items-center justify-center">
                <img 
                  src={personalDetails.photo} 
                  alt={personalDetails.name || "Profile"} 
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
            </div>
          )}
        </div>
      </header>
      
      {/* Summary Section */}
      {hasSummary && (
        <section className="py-6 px-8 bg-gray-50">
          <p className="text-gray-700 leading-relaxed">
            {personalDetails.summary}
          </p>
        </section>
      )}
      
      {/* Main Content */}
      <main className="p-8 grid grid-cols-3 gap-8">
        {/* Left Column */}
        <div className="col-span-1 space-y-8">
          {/* Skills Section */}
          {hasSkills && (
            <section>
              <h3 className="text-lg font-bold mb-4 pb-1 border-b-2" style={{ borderColor: 'var(--primary-color)', color: 'var(--primary-color)' }}>
                Skills
              </h3>
              
              <div className="space-y-3">
                {skills.map((skill) => (
                  <div key={skill.id} className="mb-2">
                    <div className="flex justify-between mb-1">
                      <span className="text-gray-700 font-medium">{skill.name || "Skill"}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="h-2 rounded-full" 
                        style={{ 
                          width: `${skill.level || 0}%`,
                          backgroundColor: 'var(--primary-color)' 
                        }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}
          
          {/* Languages Section */}
          {hasLanguages && (
            <section>
              <h3 className="text-lg font-bold mb-4 pb-1 border-b-2" style={{ borderColor: 'var(--primary-color)', color: 'var(--primary-color)' }}>
                Languages
              </h3>
              
              <ul className="space-y-2">
                {languages.map((language) => (
                  <li key={language.id} className="flex justify-between items-center pb-2">
                    <span className="text-gray-700 font-medium">{language.name || "Language"}</span>
                    <span 
                      className="text-xs px-2 py-1 rounded-full text-white"
                      style={{ backgroundColor: 'var(--primary-color)' }}
                    >
                      {language.proficiency || "Level"}
                    </span>
                  </li>
                ))}
              </ul>
            </section>
          )}
          
          {/* Social Links */}
          {hasSocialLinks && (
            <section>
              <h3 className="text-lg font-bold mb-4 pb-1 border-b-2" style={{ borderColor: 'var(--primary-color)', color: 'var(--primary-color)' }}>
                Links
              </h3>
              
              <ul className="space-y-3">
                {socialLinks.map((link) => (
                  <li key={link.id}>
                    <div className="flex items-start">
                      <LinkIcon className="w-4 h-4 mt-1 mr-2" style={{ color: 'var(--primary-color)' }} />
                      <div>
                        <div className="font-medium text-gray-700">{link.platform || "Platform"}</div>
                        <a 
                          href={link.url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-sm hover:underline break-all"
                          style={{ color: 'var(--primary-color)' }}
                        >
                          {link.url || "URL"}
                        </a>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </section>
          )}
        </div>
        
        {/* Right Column */}
        <div className="col-span-2 space-y-8">
          {/* Experience Section */}
          {hasExperience && (
            <section>
              <h3 className="text-lg font-bold mb-4 pb-1 border-b-2" style={{ borderColor: 'var(--primary-color)', color: 'var(--primary-color)' }}>
                Work Experience
              </h3>
              
              <div className="space-y-6">
                {experience.map((exp) => (
                  <div key={exp.id} className="mb-4 relative pl-6 border-l-2" style={{ borderColor: 'var(--primary-color)' }}>
                    <div className="absolute -left-[9px] top-1 w-4 h-4 rounded-full" style={{ backgroundColor: 'var(--primary-color)' }}></div>
                    <div className="flex flex-col md:flex-row md:justify-between md:items-start mb-1">
                      <h4 className="font-bold text-gray-800">{exp.position || "Position"}</h4>
                      <div className="text-sm text-gray-500 flex items-center">
                        <Calendar className="w-3 h-3 mr-1" />
                        {exp.startDate && exp.endDate ? `${exp.startDate} - ${exp.endDate}` : 
                         exp.startDate ? `${exp.startDate} - Present` : ""}
                      </div>
                    </div>
                    <div className="text-gray-700 font-medium mb-1">
                      {exp.company || "Company"}
                      {exp.location && <span className="text-gray-500"> • {exp.location}</span>}
                    </div>
                    {exp.description && (
                      <p className="text-sm text-gray-600 whitespace-pre-line mt-2">{exp.description}</p>
                    )}
                  </div>
                ))}
              </div>
            </section>
          )}
          
          {/* Education Section */}
          {hasEducation && (
            <section>
              <h3 className="text-lg font-bold mb-4 pb-1 border-b-2" style={{ borderColor: 'var(--primary-color)', color: 'var(--primary-color)' }}>
                Education
              </h3>
              
              <div className="space-y-6">
                {education.map((edu) => (
                  <div key={edu.id} className="mb-4 relative pl-6 border-l-2" style={{ borderColor: 'var(--primary-color)' }}>
                    <div className="absolute -left-[9px] top-1 w-4 h-4 rounded-full" style={{ backgroundColor: 'var(--primary-color)' }}></div>
                    <div className="flex flex-col md:flex-row md:justify-between md:items-start mb-1">
                      <h4 className="font-bold text-gray-800">{edu.degree || "Degree"}</h4>
                      <div className="text-sm text-gray-500 flex items-center">
                        <Calendar className="w-3 h-3 mr-1" />
                        {edu.startDate && edu.endDate ? `${edu.startDate} - ${edu.endDate}` : 
                         edu.startDate ? `${edu.startDate} - Present` : ""}
                      </div>
                    </div>
                    <div className="text-gray-700 font-medium mb-1">
                      {edu.institution || "Institution"}
                      {edu.fieldOfStudy && <span className="text-gray-500"> • {edu.fieldOfStudy}</span>}
                    </div>
                    {edu.description && (
                      <p className="text-sm text-gray-600 whitespace-pre-line mt-2">{edu.description}</p>
                    )}
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>
      </main>
    </div>
  );
}
