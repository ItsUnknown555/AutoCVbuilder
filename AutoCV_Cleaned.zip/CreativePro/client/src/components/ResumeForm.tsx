import { useContext, useState, useCallback } from "react";
import { useForm, FormProvider } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { ResumeContext, SettingsContext } from "@/App";
import { Resume, resumeSchema } from "@shared/schema";
import { generateUUID } from "@/lib/utils";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { Trash, Plus, FileUp, Settings2 } from "lucide-react";

export default function ResumeForm() {
  const { resumeData, setResumeData } = useContext(ResumeContext);
  const { settings, setSettings } = useContext(SettingsContext);
  const { toast } = useToast();
  
  const form = useForm<Resume>({
    resolver: zodResolver(resumeSchema),
    defaultValues: resumeData,
  });
  
  const onSubmit = useCallback((data: Resume) => {
    setResumeData(data);
    toast({
      title: "Resume Updated",
      description: "Your resume has been saved",
    });
  }, [setResumeData, toast]);

  // Handler for file upload
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const photoData = reader.result as string;
        form.setValue("personalDetails.photo", photoData);
        // Trigger form update
        form.handleSubmit(onSubmit)();
      };
      reader.readAsDataURL(file);
    }
  };

  // Add education item
  const addEducation = () => {
    const currentEducation = form.getValues("education") || [];
    form.setValue("education", [
      ...currentEducation,
      { id: generateUUID(), institution: "", degree: "", fieldOfStudy: "", startDate: "", endDate: "", description: "" }
    ]);
    form.handleSubmit(onSubmit)();
  };

  // Remove education item
  const removeEducation = (id: string) => {
    const currentEducation = form.getValues("education") || [];
    form.setValue("education", currentEducation.filter(item => item.id !== id));
    form.handleSubmit(onSubmit)();
  };

  // Add experience item
  const addExperience = () => {
    const currentExperience = form.getValues("experience") || [];
    form.setValue("experience", [
      ...currentExperience,
      { id: generateUUID(), company: "", position: "", location: "", startDate: "", endDate: "", description: "" }
    ]);
    form.handleSubmit(onSubmit)();
  };

  // Remove experience item
  const removeExperience = (id: string) => {
    const currentExperience = form.getValues("experience") || [];
    form.setValue("experience", currentExperience.filter(item => item.id !== id));
    form.handleSubmit(onSubmit)();
  };

  // Add skill item
  const addSkill = () => {
    const currentSkills = form.getValues("skills") || [];
    form.setValue("skills", [
      ...currentSkills,
      { id: generateUUID(), name: "", level: 50 }
    ]);
    form.handleSubmit(onSubmit)();
  };

  // Remove skill item
  const removeSkill = (id: string) => {
    const currentSkills = form.getValues("skills") || [];
    form.setValue("skills", currentSkills.filter(item => item.id !== id));
    form.handleSubmit(onSubmit)();
  };

  // Add language item
  const addLanguage = () => {
    const currentLanguages = form.getValues("languages") || [];
    form.setValue("languages", [
      ...currentLanguages,
      { id: generateUUID(), name: "", proficiency: "Elementary" }
    ]);
    form.handleSubmit(onSubmit)();
  };

  // Remove language item
  const removeLanguage = (id: string) => {
    const currentLanguages = form.getValues("languages") || [];
    form.setValue("languages", currentLanguages.filter(item => item.id !== id));
    form.handleSubmit(onSubmit)();
  };

  // Add social link item
  const addSocialLink = () => {
    const currentSocialLinks = form.getValues("socialLinks") || [];
    form.setValue("socialLinks", [
      ...currentSocialLinks,
      { id: generateUUID(), platform: "", url: "" }
    ]);
    form.handleSubmit(onSubmit)();
  };

  // Remove social link item
  const removeSocialLink = (id: string) => {
    const currentSocialLinks = form.getValues("socialLinks") || [];
    form.setValue("socialLinks", currentSocialLinks.filter(item => item.id !== id));
    form.handleSubmit(onSubmit)();
  };

  // Auto-save on change
  const autoSave = () => {
    form.handleSubmit(onSubmit)();
  };

  return (
    <FormProvider {...form}>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <Tabs defaultValue="personalDetails" className="w-full">
            <TabsList className="grid grid-cols-7 mb-4">
              <TabsTrigger value="personalDetails">Personal</TabsTrigger>
              <TabsTrigger value="education">Education</TabsTrigger>
              <TabsTrigger value="experience">Experience</TabsTrigger>
              <TabsTrigger value="skills">Skills</TabsTrigger>
              <TabsTrigger value="languages">Languages</TabsTrigger>
              <TabsTrigger value="socialLinks">Links</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>

            {/* Personal Details Tab */}
            <TabsContent value="personalDetails">
              <Card>
                <CardHeader>
                  <CardTitle>Personal Details</CardTitle>
                  <CardDescription>
                    Basic information about yourself
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex flex-col md:flex-row gap-4">
                    {/* Photo Upload */}
                    <div className="w-full md:w-1/3 flex flex-col items-center justify-center">
                      <div className="w-32 h-32 border-2 border-dashed rounded-full flex items-center justify-center overflow-hidden mb-2">
                        {form.watch("personalDetails.photo") ? (
                          <img 
                            src={form.watch("personalDetails.photo")} 
                            alt="Profile" 
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <FileUp className="w-8 h-8 text-gray-400" />
                        )}
                      </div>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        className="mt-2"
                        onClick={() => document.getElementById('photo-upload')?.click()}
                      >
                        Upload Photo
                      </Button>
                      <input
                        id="photo-upload"
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handlePhotoUpload}
                      />
                    </div>

                    {/* Basic Info */}
                    <div className="w-full md:w-2/3 space-y-4">
                      <FormField
                        control={form.control}
                        name="personalDetails.name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Full Name</FormLabel>
                            <FormControl>
                              <Input {...field} onBlur={autoSave} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="personalDetails.title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Professional Title</FormLabel>
                            <FormControl>
                              <Input {...field} onBlur={autoSave} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="personalDetails.email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input {...field} onBlur={autoSave} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="personalDetails.phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone</FormLabel>
                          <FormControl>
                            <Input {...field} onBlur={autoSave} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="personalDetails.address"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Address</FormLabel>
                        <FormControl>
                          <Input {...field} onBlur={autoSave} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="personalDetails.summary"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Professional Summary</FormLabel>
                        <FormControl>
                          <Textarea 
                            {...field} 
                            onBlur={autoSave}
                            className="h-32"
                          />
                        </FormControl>
                        <FormDescription>
                          Write a short summary about yourself and your career
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
                <CardFooter className="flex justify-end">
                  <Button type="button" onClick={form.handleSubmit(onSubmit)}>Save</Button>
                </CardFooter>
              </Card>
            </TabsContent>

            {/* Education Tab */}
            <TabsContent value="education">
              <Card>
                <CardHeader>
                  <CardTitle>Education</CardTitle>
                  <CardDescription>
                    Your academic background
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Accordion type="multiple" className="w-full">
                    {form.watch("education")?.map((edu, index) => (
                      <AccordionItem key={edu.id} value={edu.id}>
                        <AccordionTrigger className="hover:bg-gray-100 dark:hover:bg-gray-800 px-4 rounded-md">
                          {edu.institution || edu.degree ? 
                            `${edu.institution || 'Institution'} - ${edu.degree || 'Degree'}` : 
                            `Education #${index + 1}`
                          }
                        </AccordionTrigger>
                        <AccordionContent className="px-4 pt-4 space-y-4">
                          <FormField
                            control={form.control}
                            name={`education.${index}.institution`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Institution</FormLabel>
                                <FormControl>
                                  <Input {...field} onBlur={autoSave} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name={`education.${index}.degree`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Degree</FormLabel>
                                <FormControl>
                                  <Input {...field} onBlur={autoSave} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name={`education.${index}.fieldOfStudy`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Field of Study</FormLabel>
                                <FormControl>
                                  <Input {...field} onBlur={autoSave} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={form.control}
                              name={`education.${index}.startDate`}
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Start Date</FormLabel>
                                  <FormControl>
                                    <Input {...field} onBlur={autoSave} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={form.control}
                              name={`education.${index}.endDate`}
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>End Date</FormLabel>
                                  <FormControl>
                                    <Input {...field} onBlur={autoSave} placeholder="Present" />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          <FormField
                            control={form.control}
                            name={`education.${index}.description`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Description</FormLabel>
                                <FormControl>
                                  <Textarea {...field} onBlur={autoSave} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <Button 
                            type="button" 
                            variant="destructive"
                            size="sm"
                            onClick={() => removeEducation(edu.id)}
                            className="mt-2"
                          >
                            <Trash className="w-4 h-4 mr-2" />
                            Remove
                          </Button>
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                  
                  {(!form.watch("education") || form.watch("education").length === 0) && (
                    <div className="text-center py-4 text-gray-500">
                      No education entries added yet
                    </div>
                  )}
                  
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={addEducation}
                    className="w-full mt-4"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Education
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Experience Tab */}
            <TabsContent value="experience">
              <Card>
                <CardHeader>
                  <CardTitle>Work Experience</CardTitle>
                  <CardDescription>
                    Your professional experience
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Accordion type="multiple" className="w-full">
                    {form.watch("experience")?.map((exp, index) => (
                      <AccordionItem key={exp.id} value={exp.id}>
                        <AccordionTrigger className="hover:bg-gray-100 dark:hover:bg-gray-800 px-4 rounded-md">
                          {exp.company || exp.position ? 
                            `${exp.company || 'Company'} - ${exp.position || 'Position'}` : 
                            `Experience #${index + 1}`
                          }
                        </AccordionTrigger>
                        <AccordionContent className="px-4 pt-4 space-y-4">
                          <FormField
                            control={form.control}
                            name={`experience.${index}.company`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Company</FormLabel>
                                <FormControl>
                                  <Input {...field} onBlur={autoSave} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name={`experience.${index}.position`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Position</FormLabel>
                                <FormControl>
                                  <Input {...field} onBlur={autoSave} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name={`experience.${index}.location`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Location</FormLabel>
                                <FormControl>
                                  <Input {...field} onBlur={autoSave} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={form.control}
                              name={`experience.${index}.startDate`}
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Start Date</FormLabel>
                                  <FormControl>
                                    <Input {...field} onBlur={autoSave} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={form.control}
                              name={`experience.${index}.endDate`}
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>End Date</FormLabel>
                                  <FormControl>
                                    <Input {...field} onBlur={autoSave} placeholder="Present" />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          <FormField
                            control={form.control}
                            name={`experience.${index}.description`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Description</FormLabel>
                                <FormControl>
                                  <Textarea {...field} onBlur={autoSave} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <Button 
                            type="button" 
                            variant="destructive"
                            size="sm"
                            onClick={() => removeExperience(exp.id)}
                            className="mt-2"
                          >
                            <Trash className="w-4 h-4 mr-2" />
                            Remove
                          </Button>
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                  
                  {(!form.watch("experience") || form.watch("experience").length === 0) && (
                    <div className="text-center py-4 text-gray-500">
                      No experience entries added yet
                    </div>
                  )}
                  
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={addExperience}
                    className="w-full mt-4"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Experience
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Skills Tab */}
            <TabsContent value="skills">
              <Card>
                <CardHeader>
                  <CardTitle>Skills</CardTitle>
                  <CardDescription>
                    Your key professional skills
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {form.watch("skills")?.map((skill, index) => (
                    <div key={skill.id} className="p-4 border rounded-md space-y-4 relative">
                      <FormField
                        control={form.control}
                        name={`skills.${index}.name`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Skill Name</FormLabel>
                            <FormControl>
                              <Input {...field} onBlur={autoSave} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name={`skills.${index}.level`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Skill Level ({field.value}%)</FormLabel>
                            <FormControl>
                              <Slider
                                defaultValue={[field.value || 50]}
                                max={100}
                                step={5}
                                onValueChange={(value) => {
                                  field.onChange(value[0]);
                                  autoSave();
                                }}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button 
                        type="button" 
                        variant="ghost"
                        size="icon"
                        onClick={() => removeSkill(skill.id)}
                        className="absolute top-2 right-2 text-red-500 h-8 w-8"
                      >
                        <Trash className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                  
                  {(!form.watch("skills") || form.watch("skills").length === 0) && (
                    <div className="text-center py-4 text-gray-500">
                      No skills added yet
                    </div>
                  )}
                  
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={addSkill}
                    className="w-full mt-4"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Skill
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Languages Tab */}
            <TabsContent value="languages">
              <Card>
                <CardHeader>
                  <CardTitle>Languages</CardTitle>
                  <CardDescription>
                    Languages you speak
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {form.watch("languages")?.map((language, index) => (
                    <div key={language.id} className="p-4 border rounded-md space-y-4 relative">
                      <FormField
                        control={form.control}
                        name={`languages.${index}.name`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Language</FormLabel>
                            <FormControl>
                              <Input {...field} onBlur={autoSave} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name={`languages.${index}.proficiency`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Proficiency Level</FormLabel>
                            <Select 
                              onValueChange={(value) => {
                                field.onChange(value);
                                autoSave();
                              }} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select proficiency level" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="Native">Native</SelectItem>
                                <SelectItem value="Fluent">Fluent</SelectItem>
                                <SelectItem value="Advanced">Advanced</SelectItem>
                                <SelectItem value="Intermediate">Intermediate</SelectItem>
                                <SelectItem value="Elementary">Elementary</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button 
                        type="button" 
                        variant="ghost"
                        size="icon"
                        onClick={() => removeLanguage(language.id)}
                        className="absolute top-2 right-2 text-red-500 h-8 w-8"
                      >
                        <Trash className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                  
                  {(!form.watch("languages") || form.watch("languages").length === 0) && (
                    <div className="text-center py-4 text-gray-500">
                      No languages added yet
                    </div>
                  )}
                  
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={addLanguage}
                    className="w-full mt-4"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Language
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Social Links Tab */}
            <TabsContent value="socialLinks">
              <Card>
                <CardHeader>
                  <CardTitle>Social Links</CardTitle>
                  <CardDescription>
                    Add links to your online profiles
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {form.watch("socialLinks")?.map((link, index) => (
                    <div key={link.id} className="p-4 border rounded-md space-y-4 relative">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name={`socialLinks.${index}.platform`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Platform</FormLabel>
                              <Select 
                                onValueChange={(value) => {
                                  field.onChange(value);
                                  autoSave();
                                }} 
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select platform" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="LinkedIn">LinkedIn</SelectItem>
                                  <SelectItem value="GitHub">GitHub</SelectItem>
                                  <SelectItem value="Twitter">Twitter</SelectItem>
                                  <SelectItem value="Portfolio">Portfolio</SelectItem>
                                  <SelectItem value="Blog">Blog</SelectItem>
                                  <SelectItem value="Other">Other</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name={`socialLinks.${index}.url`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>URL</FormLabel>
                              <FormControl>
                                <Input {...field} onBlur={autoSave} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <Button 
                        type="button" 
                        variant="ghost"
                        size="icon"
                        onClick={() => removeSocialLink(link.id)}
                        className="absolute top-2 right-2 text-red-500 h-8 w-8"
                      >
                        <Trash className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                  
                  {(!form.watch("socialLinks") || form.watch("socialLinks").length === 0) && (
                    <div className="text-center py-4 text-gray-500">
                      No social links added yet
                    </div>
                  )}
                  
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={addSocialLink}
                    className="w-full mt-4"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Social Link
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Settings2 className="w-5 h-5 mr-2" />
                    Resume Settings
                  </CardTitle>
                  <CardDescription>
                    Customize the appearance of your resume
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Template</h3>
                    <RadioGroup 
                      defaultValue={settings.template}
                      onValueChange={(value) => {
                        setSettings({...settings, template: value as any});
                      }}
                      className="grid grid-cols-1 md:grid-cols-3 gap-4"
                    >
                      <div className="border rounded-lg p-4 flex flex-col items-center">
                        <div className="border rounded mb-3 w-full h-24 bg-gray-50 flex items-center justify-center text-xs text-gray-500">
                          Minimalist Preview
                        </div>
                        <RadioGroupItem value="minimalist" id="minimalist" className="mb-1" />
                        <Label htmlFor="minimalist">Minimalist</Label>
                      </div>
                      <div className="border rounded-lg p-4 flex flex-col items-center">
                        <div className="border rounded mb-3 w-full h-24 bg-gray-50 flex items-center justify-center text-xs text-gray-500">
                          Modern Preview
                        </div>
                        <RadioGroupItem value="modern" id="modern" className="mb-1" />
                        <Label htmlFor="modern">Modern</Label>
                      </div>
                      <div className="border rounded-lg p-4 flex flex-col items-center">
                        <div className="border rounded mb-3 w-full h-24 bg-gray-50 flex items-center justify-center text-xs text-gray-500">
                          Classic Preview
                        </div>
                        <RadioGroupItem value="classic" id="classic" className="mb-1" />
                        <Label htmlFor="classic">Classic</Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Font</h3>
                    <Select 
                      value={settings.font}
                      onValueChange={(value) => {
                        setSettings({...settings, font: value});
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select font" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Inter">Inter</SelectItem>
                        <SelectItem value="Roboto">Roboto</SelectItem>
                        <SelectItem value="Open Sans">Open Sans</SelectItem>
                        <SelectItem value="Lato">Lato</SelectItem>
                        <SelectItem value="Montserrat">Montserrat</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Primary Color</h3>
                    <div className="grid grid-cols-5 gap-4">
                      {[
                        "#6366F1", // Indigo
                        "#8B5CF6", // Violet
                        "#EC4899", // Pink
                        "#F43F5E", // Rose
                        "#06B6D4", // Cyan
                        "#10B981", // Emerald
                        "#22C55E", // Green
                        "#F59E0B", // Amber
                        "#000000", // Black
                        "#64748B"  // Slate
                      ].map((color) => (
                        <button
                          key={color}
                          type="button"
                          className={`w-full h-12 rounded-md ${settings.primaryColor === color ? 'ring-2 ring-offset-2' : ''}`}
                          style={{ backgroundColor: color }}
                          onClick={() => setSettings({...settings, primaryColor: color})}
                          aria-label={`Select color ${color}`}
                        />
                      ))}
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Font Size</h3>
                    <Select 
                      value={settings.fontSize}
                      onValueChange={(value) => {
                        setSettings({...settings, fontSize: value});
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select font size" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="small">Small</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="large">Large</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <div className="flex justify-end">
            <Button type="submit">Save Resume</Button>
          </div>
        </form>
      </Form>
    </FormProvider>
  );
}
