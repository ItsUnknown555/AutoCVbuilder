import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Import html2pdf for PDF export
import { html2pdf } from "html2pdf.js";

// Make html2pdf available globally
window.html2pdf = html2pdf;

createRoot(document.getElementById("root")!).render(<App />);
