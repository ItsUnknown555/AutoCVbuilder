export interface ResumeSettings {
  template: 'minimalist' | 'modern' | 'classic';
  font: string;
  primaryColor: string;
  fontSize: string;
}

export interface SettingsState {
  settings: ResumeSettings;
  setSettings: (settings: ResumeSettings) => void;
}
