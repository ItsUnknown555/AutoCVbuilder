import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { Resume } from "@shared/schema";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const DEFAULT_RESUME_DATA: Resume = {
  personalDetails: {
    name: "",
    email: "",
    phone: "",
    photo: "",
    title: "",
    address: "",
    summary: "",
  },
  education: [],
  experience: [],
  skills: [],
  languages: [],
  socialLinks: [],
};

export const DEFAULT_SETTINGS = {
  template: "minimalist" as const,
  font: "Inter",
  primaryColor: "#6366F1",
  fontSize: "medium",
};

export function generateUUID(): string {
  return Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15);
}

export function loadResumeFromStorage(): Resume | null {
  try {
    const saved = localStorage.getItem("resumeData");
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (e) {
    console.error("Failed to load resume from storage:", e);
  }
  return null;
}

export function saveResumeToStorage(resume: Resume): void {
  try {
    localStorage.setItem("resumeData", JSON.stringify(resume));
  } catch (e) {
    console.error("Failed to save resume to storage:", e);
  }
}

export function loadSettingsFromStorage() {
  try {
    const saved = localStorage.getItem("resumeSettings");
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (e) {
    console.error("Failed to load settings from storage:", e);
  }
  return DEFAULT_SETTINGS;
}

export function saveSettingsToStorage(settings: any): void {
  try {
    localStorage.setItem("resumeSettings", JSON.stringify(settings));
  } catch (e) {
    console.error("Failed to save settings to storage:", e);
  }
}
